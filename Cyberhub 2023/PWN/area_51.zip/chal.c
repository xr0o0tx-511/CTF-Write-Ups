#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

void menu()
{
	char identification[64];
	printf("--- AREA 51 IDENTIFICATION START ---\n");
	printf("IDENTIFY YOURSELF: ");
	fflush(stdout);
	fgets(identification, sizeof(identification), stdin);
	printf(identification);
	printf("IDENTIFICATION COMPLETE. REQUESTING INSTRUCTIONS...\n");
	fflush(stdout);
}

void get_instructions()
{
	char instructions[32];
	printf("=== REQUEST INSTRUCTIONS ===\n");
	printf("SEND INSTRUCTIONS: ");
	fflush(stdout);
	gets(instructions);
	printf("INSTRUCTIONS: %s\n", instructions);
	printf("THANK YOU. ENDING TRANSMISSION.\n");
	fflush(stdout);
}

int main()
{
	menu();
	get_instructions();
	printf("--- AREA 51 TRANSMISSION END ---\n");
	fflush(stdout);
	return 0;
}