#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv)
{
	printf("Ramadan Kareem!\nI know you must be hungry and cannot wait for iftar, but unfortunately iftar cannot happen unless you set the 'iftar_lock' variable to anything other than zero!\nCan you help?\n\nSend your input: ");
	volatile int iftar_lock;
	char buffer[64];
	iftar_lock = 0;
	gets(buffer);
	if(iftar_lock == 0) {
        printf("\nTry again, you got %d\n", iftar_lock);
	} else {
        printf("\nCongrats! You successfully modified the variable!\nThe flag is: %s\n", "SAMPLE_FLAG_DO_NOT_SUBMIT");
	}
	return 0;
}